# DATA ETHICS QUIZ STUDY GUIDE
## GDPR + Philosophical Frameworks

**Format:** 5% of grade | Covers Articles 5-7, 9 + 4 Philosophical Frameworks

---

## SECTION 1: PHILOSOPHICAL FRAMEWORKS
### Framework Overview & Critical Weaknesses

**1. UTILITARIANISM (Jeremy Bentham, 1748-1832)**

*Core Principle:* "The greatest good to the greatest number of people" (the fundamental axiom)

**Key Weaknesses to Know:**
- Difficulty in Measuring Happiness: How do you quantify "9 out of 10" happiness precisely?
- Ignores Individual Rights: Example from slides — is letting everyone pick lemons from my tree ethical even if it makes them happy, but violates my property rights?
- Problem of Aggregation: Is making one person extremely happy the same as making two people moderately happy?
- Unforeseen Consequences: What if lemonade made from the lemons causes disease you didn't know about?
- Cognitive Load: Calculating happiness/unhappiness for you, the giver, the recipients, and all future consequences becomes impossibly complex

**Quiz Application:** You might see a scenario asking whether a data company's use of employee data maximizes overall happiness — be ready to identify why this framework struggles with measurement and unintended consequences.

---

**2. DEONTOLOGY (Immanuel Kant, 1724-1804)**

*Core Principle:* The "Categorical Imperative" — "Act only according to that maxim whereby you can, at the same time, will that it should become a universal law."

**Key Weaknesses to Know:**
- Rigidity/Ignoring Consequences: Must adhere to rules regardless of outcomes. Example: Is lying always wrong, even to save a life?
- Conflict of Duties: What if duty to tell truth conflicts with duty to protect life? (the "save a life by lying" paradox)
- Cognitive Load: Determining what constitutes a universalizable maxim is philosophically challenging — what about exceptions?
- Underestimation of Emotions: Prioritizes reason/logic over human emotion, but psychological research shows people act on feelings first

**Quiz Application:** A scenario might present a data company's rule-based approach to privacy (e.g., "never share employee health data") and ask whether deontology adequately addresses a case where the rule conflicts with another obligation.

---

**3. CONTRACTUALISM (T.M. Scanlon, 1940-)**

*Core Principle:* "An action would be wrong if it is one that I could not justify to others on grounds I could expect them to accept."

**Key Weaknesses to Know:**
- Problem of Aggregation: Difficult when overall good to a group outweighs individual interests (e.g., sacrificing one person to save many — hard to justify to the person being sacrificed)
- Scope of the Contract: Who's included? Future generations? Animals? The environment?
- Overly Egalitarian: Many relationships aren't negotiated on equal footing (employer-employee, parent-child)
- Cognitive Load & Practicality: Requiring justification that others can't reasonably reject might be too demanding when quick decisions are necessary

**Quiz Application:** Expect a question about whether consent-based data practices (contractual agreements) adequately protect all stakeholders, especially vulnerable populations.

---

**4. PARTICULARISM (Jonathan Dancy, 1948-)**

*Core Principle:* "A feature that makes one action better can make another one worse, and make no difference at all to a third." Moral principles are "crutches" that morally sensitive people wouldn't need.

**Key Weaknesses to Know:**
- Counterintuitive: We teach morality through principles ("Don't lie," "Be honest") — people find principles useful
- Inconsistency: Without moral principles, similar situations might be judged differently with no guarantee of consistency
- Subjectivity: Opens door to extreme subjectivity where judgments rely solely on individual intuition without rational basis
- Ignores Similarities: By focusing exclusively on each situation's uniqueness, you might miss important similarities between cases

**Quiz Application:** You might see a scenario asking how particularism would handle the same data practice applied to two different populations — be ready to explain why its flexibility is both a strength and a weakness.

---

## SECTION 2: GDPR ARTICLES 5-7 & 9

### ARTICLE 5: Core Data Processing Principles

**Principle 1: Lawful, Fair, Transparent**
- Data must be processed lawfully (one of 6 legal grounds must apply)
- Fair processing — not deceptive or misleading
- Transparent — clear information to data subjects

**CASE STUDY:** *La Liga (Spanish Football League)*
- **Violation:** Used mobile app to secretly listen whether fans were watching games; tracked location to detect piracy
- **Why GDPR Violation:** Failed transparency — users didn't know their microphone/location was being monitored
- **Fine:** €500,000
- **Key Takeaway:** Users must have clear, upfront knowledge of what data is being collected and why

---

**Principle 2: Specific, Explicit, & Legitimate Consent**
- Consent must be as specific as possible
- Cannot get general consent ("research") — must specify exactly: "Research on consumer habits related to electronics"
- Must consider ALL uses of data in consent language

**CASE STUDY:** *Belgian Mayor*
- **Violation:** Received emails about housing development → saved addresses → used them for election campaign emails
- **Why GDPR Violation:** Consent was specific to housing development issue, not expanded to political use
- **Key Takeaway:** You cannot repurpose data for new uses without specific new consent

---

**Principle 3: Data Minimization**
- Adequate, relevant, and limited to what is necessary
- **CRITICAL:** Must have specific reason for collecting each data point
- Cannot collect data "just in case" you find something interesting
- Test: "What would we do/change if this data point was significant?" If answer is "not much," DON'T collect it

**CASE STUDY:** *Spartoo (Fashion Website)*
- **Violation:** Stored ALL telephone conversations with customers for training/evaluation, even though the trainer listened to only 1 recording per week per employee
- **Why GDPR Violation:** Excessive data — storing hundreds of calls to listen to one was not necessary/proportional
- **Fine:** French authorities imposed fine
- **Key Takeaway:** Storage must match actual need; retention beyond necessity is a violation

---

**Principle 4: Accuracy & Up-to-Date**
- Data must be accurate when collected AND kept accurate over time
- You're responsible for updates
- Inaccuracy can cause harm

**CASE STUDY:** *Hungarian Bank*
- **Violation:** Did not keep accurate phone numbers; repeatedly contacted wrong customer about loan
- **Why GDPR Violation:** Failed to maintain accuracy; incorrect data was processed
- **Key Takeaway:** Data quality is an ongoing responsibility, not one-time

---

**Principle 5: De-identification & Storage Limitation**
- Permit identification of subjects no longer than necessary
- Remove identifying information as early as possible
- Store datasets only as long as needed (almost all data is re-identifiable under certain conditions)
- **Remember:** Encryption ≠ anonymization

**CASE STUDY:** *French Health Website (like WebMD)*
- **Violation:** Offered health quizzes; kept quiz info + IP addresses for years
- **Further Violation:** After 2 years, encrypted the data through third-party contractor but this is NOT anonymization
- **Why GDPR Violation:** Failed storage limitation (kept too long) + failed de-identification (encryption doesn't de-identify)
- **Key Takeaway:** Encryption protects data in transit but doesn't remove identifiability; true anonymization is irreversible

---

**Principle 6: Security**
- Protection against unlawful processing and accidental loss
- **Critical:** If you're hacked, it's YOUR fault — not just the hacker's
- You're responsible for maintaining security measures

---

### ARTICLE 7: Responsibility (Accountability)
- In cases of hacking or third-party contractor misuse, the original company is responsible
- You cannot pass liability to your vendors/contractors

**CASE STUDY:** *British Airways Hacking*
- **Violation:** Airline was hacked; customer payment data was stolen
- **Why GDPR Violation:** BA was held responsible for ensuring security, even though an external hacker was the perpetrator
- **Key Takeaway:** You cannot outsource your responsibility for data security

---

### ARTICLE 9: Special Categories of Data
Data revealing the following is prohibited EXCEPT with explicit consent or special circumstances:
- Racial/ethnic origin
- Political opinions
- Religious or philosophical beliefs
- Trade union membership
- Genetic data
- Biometric data
- Health data
- Sex life or sexual orientation

**Key Distinction:** Article 9 data requires HIGHER protection than ordinary personal data

---

## SECTION 3: THE 6 LEGAL GROUNDS FOR PROCESSING

You must have at least ONE of these to process data lawfully:

1. **Unambiguous Consent** — Clear, active opt-in
2. **Contract Performance** — Data needed to fulfill a contract (no separate consent needed)
3. **Legal Obligation** — Required by law (no consent needed)
4. **Vital Interests** — Life-or-death emergency (no consent needed)
5. **Public Interest** — Serves public policy goals (no consent needed)
6. **Legitimate Interest** — Company interest balanced against data subject rights (MOST AMBIGUOUS)

---

## SECTION 4: CONSENT REQUIREMENTS

### Clarity Requirements:
- Distinguishable from other content (separate part of website)
- Easily accessible
- Plain, clear language

### Revocation Requirements:
- Must be told consent is voluntary and can be revoked anytime
- Just as easy to revoke as to give consent
- Cannot demand consent as condition for service unless absolutely necessary

### Freely Given:
- Cannot be forced condition for using service/platform
- **Case:** Facebook fined €390M because users had no option to use platform without advertising consent

---

## SECTION 5: CONSENT MUST INCLUDE (Article 13)

- Name and contact details of company
- Purposes of processing and legal basis (why you need this data)
- Recipients or categories of recipients
- Information on any third parties you'll share with and why
- Data protection officer contact (if applicable — large EU-presence companies)

---

## PRACTICE SCENARIOS

### Scenario 1: Educational Research
A university wants to collect survey data from employees about burnout. They plan to:
- Collect name, email, department, burnout scale score, health conditions (to correlate with burnout)
- Keep data for 3 years for analysis
- Share anonymized findings with HR

**Questions:**
1. Is health data collection allowed under Article 9? What would they need?
2. Which Principle(s) might be violated?
3. Does data minimization apply — should they collect health data?
4. What philosophical framework would question this practice?

**Answer Guide:**
1. Health data = Article 9 special category. Needs explicit consent + legitimate reason (research is acceptable with consent)
2. Principle 2 (specific consent) + Principle 3 (data minimization) — is health data necessary for burnout research? Questionable
3. Yes — if health data isn't essential to research question, shouldn't collect it. Apply the test: "What would we do if we found correlation?" If answer is "interesting but doesn't change anything," don't collect
4. **Utilitarianism:** Might justify (overall good of understanding burnout). **Deontology:** Strict rule — only collect necessary data. **Particularism:** Depends on context — sensitive employees might have additional concerns

---

### Scenario 2: Employee Monitoring
A tech company wants to:
- Monitor badge swipe times to track individual productivity
- Use IP location data to ensure remote workers are actually working
- Retain all data for 6 months in case of disputes

**Questions:**
1. What legal ground(s) could they claim?
2. Does this violate any principles? Which ones?
3. Is 6 months storage compliant?
4. Which philosophical framework would be most critical?

**Answer Guide:**
1. Could claim: Legitimate Interest (company efficiency) + Contract (employment contract). NOT vital interests. Legitimate Interest is weakest here.
2. Violates: Principle 1 (fairness/transparency — monitoring without clear consent?), Principle 3 (data minimization — is productivity data from location necessary?), Principle 5 (storage — is 6 months necessary?)
3. Storage depends on necessity. If disputes resolved in 30 days, 6 months is excessive. Must justify retention period.
4. **Deontology:** Would question whether tracking employees is universalizable as principle. **Contractualism:** Employee might not reasonably accept location tracking. **Particularism:** Depends on context — is this a high-security role or routine office?

---

### Scenario 3: Marketing Database
A retail company has:
- Collected customer email from checkout for "occasional promotions"
- Over 2 years, sent marketing emails about jewelry, clothing, home goods, travel
- Pre-checked opt-in box for "marketing communications"
- Sold email list to third-party travel vendor (not mentioned in original signup)

**Questions:**
1. Is the pre-checked box compliant?
2. Is the scope of marketing ("occasional" vs. multiple categories) compliant?
3. Is third-party sharing compliant?
4. How would you fix these violations?

**Answer Guide:**
1. **NO** — Google fined €50M partly for pre-checked boxes. Must be active opt-in.
2. **NO** — Principle 2 (specific consent) requires stating exact purposes. "Occasional promotions" is vague; must specify "jewelry, clothing, home goods" etc.
3. **NO** — Principle 2 + Article 13 requires disclosing third-party sharing. Original consent didn't mention travel vendor.
4. Fixes: (a) Clear, separate opt-in checkbox for each marketing category, (b) If sharing with vendors, must disclose and get specific consent, (c) Make revocation easy

---

### Scenario 4: Health App
A meditation app collects:
- Daily mood ratings (Article 9: psychological state)
- Meditation session duration
- Heart rate data (Article 9: health-related biometric)
- Location data during sessions
- User keeps data indefinitely for "future research"

**Questions:**
1. What Article 9 categories are involved?
2. What about de-identification and storage?
3. What legal grounds could apply?
4. How does the "Know Your Brand" Nazi example inform this?

**Answer Guide:**
1. Psychological data + health biometric data = both Article 9 special categories. Needs explicit consent + legitimate reason.
2. **Storage violation:** Indefinite retention violates Principle 5. Should delete after research period ends. Encryption of heart rate + location could re-identify users even if name removed.
3. Could claim: Explicit Consent (if obtained) + Public Interest (health research). Legitimate Interest alone insufficient for Article 9 data.
4. **"Know Your Brand" lesson:** Nazi regime's detailed personal records (size, shape, character traits, religion, criminal records) show why data collection about intimate characteristics is dangerous. Article 9 exists specifically to protect sensitive categories. Even with "good intentions," comprehensive personal data can be misused.

---

### Scenario 5: Philosophical Analysis - Lending Decision
A bank uses an algorithm trained on historical lending data to decide loan approvals. The data includes:
- Credit history
- Zip code (which correlates with race)
- Employment status
- Age

**Question:** Analyze this practice through all 4 frameworks.

**Answer Guide:**

**Utilitarianism:** 
- Pro: Algorithm maximizes overall lending efficiency and profit
- Con: Ignores harm to individuals denied loans due to zip code proxy discrimination; unforeseen consequences if algorithm perpetuates racial inequity

**Deontology:**
- Would ask: "Can I universalize the rule 'use location data as lending criterion'?" 
- Likely says NO — inconsistent with dignity of equal treatment; violates duty of fairness
- Might also violate duty to avoid deception (hiding that zip code = proxy for race)

**Contractualism:**
- Could I justify this practice to someone denied a loan because of zip code?
- They could reasonably reject: "I'm being denied on grounds I didn't consent to and cannot control"
- Failed the standard: Could not justify it on grounds they'd accept

**Particularism:**
- Zip code feature that helps some applications might harm others
- Same factor (location) could be relevant in one context, irrelevant in another
- Would need to examine each situation's unique context rather than apply blanket rule

**Key Insight:** All frameworks except (arguably) utilitarianism have concerns about this practice. This is why GDPR Article 9 + Principle 1 (fairness) exist.

---

## QUICK REFERENCE: COMMON GDPR VIOLATIONS

| Violation | Principle | Relevant Case | Fix |
|-----------|-----------|---------------|-----|
| Secret data collection (listening) | 1 | La Liga | Transparent disclosure upfront |
| Scope creep (new purpose) | 2 | Belgian Mayor | Get new specific consent |
| Excessive storage | 3 | Spartoo | Keep only what's needed |
| Inaccurate data | 4 | Hungarian Bank | Update/maintain accuracy |
| Storing identifiable data long-term | 5 | French Health Website | De-identify or delete promptly |
| Being hacked | 6+7 | British Airways | Implement security; take responsibility |
| Pre-checked consent | Multiple | Google (€50M) | Active opt-in only |
| Forced consent | Multiple | Facebook (€390M) | Separate service access from consent |
| Article 9 data without consent | 9 | All scenarios | Get explicit consent for sensitive categories |

---

## EXAM STRATEGY

**What to Expect:**
- 1-2 scenario questions requiring case analysis
- 2-3 framework questions
- 2-3 principle/article knowledge questions
- Possibly a "spot the violation" question combining multiple principles

**How to Approach:**
1. **Scenario questions:** Name the principle, cite relevant case, identify fix
2. **Framework questions:** State core principle, name 1-2 weaknesses, apply to context
3. **Principle questions:** Know examples (cases) and why they matter
4. **Spot violations:** Look for: secret collection, scope creep, excessive storage, lack of consent, forced consent, Article 9 special categories without protection

**Key Phrases to Use:**
- "This violates Principle X because..."
- "Similar to the [Case Name] case where..."
- "A [framework] perspective would argue..."
- "Specifically, Article [X] requires..."
- "The data minimization principle means..."

---

## FINAL REVIEW: 7 PRINCIPLES SUMMARY

1. **Lawful, Fair, Transparent** ← La Liga violated this
2. **Specific, Explicit Consent** ← Belgian Mayor violated this
3. **Data Minimization** ← Spartoo violated this
4. **Accurate & Up-to-Date** ← Hungarian Bank violated this
5. **De-identification & Storage Limitation** ← French Health Website violated this
6. **Security** ← British Airways violated this
7. **Responsibility** ← British Airways (company's fault, not just hacker's)

Plus **Article 9:** Special categories need higher protection

And **6 Legal Grounds:** At least one must justify processing

Good luck on your quiz! You've got this.
